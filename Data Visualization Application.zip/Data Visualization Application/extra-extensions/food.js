function Food(){
    this.name = "Food Product";
    
    this.id = "food";
    
    this.title = "Disparity between quantity of food product purchased by UK households (Average person/week)";
    
    this.loaded = false;
    
    var bubbles = [];
    var maxAmt;
    var years = [];
    var nameDiv; //To hold the name display div
    
    this.preload = function() {
        var self = this;
        this.data = loadTable('./data/food/foodData.csv', 'csv', 'header',
        function(table) {
            self.loaded = true;
        });
    };
    
//START of own code PART 1
    this.setup = function() {
        this.data_setup();
        
        //div for bubble names that will be displayed when mouse hovers over bubbles
        nameDiv = createDiv('').id('bubble-name'); 
        nameDiv.style('position', 'absolute');
        nameDiv.style('bottom', '80px');
        nameDiv.style('left', '65%');
        nameDiv.style('transform', 'translateX(-50%)');
        nameDiv.style('color', 'red'); // Text color
        nameDiv.style('padding', '10px');
        nameDiv.style('font-size', '16px');
        nameDiv.style('font-weight', 'bold');
    }
    
    this.destroy = function() {
        select('#years').html(""); //Remove the dropbox
        nameDiv.remove();
    }
    
//END of own code PART 1
    
    this.draw = function() {
        noStroke();
        if (!this.loaded) {
            console.log('Data has not been loaded yet!');
            return;
        }

        translate(width / 2, height / 2);
        
//START of own code PART 2
        var displayName = false;
        for (var i = 0; i < bubbles.length; i++) {
            bubbles[i].update(bubbles);
            bubbles[i].draw();
            if (bubbles[i].isMouseOverBubble()) {
                nameDiv.html(bubbles[i].name);
                nameDiv.style('display', 'block'); //displays the name div
                displayName = true;
            }
        }
        if (!displayName) {
            nameDiv.html(''); //clear food name if no bubble is hovered
            nameDiv.style('display', 'none');
        }
        
        this.drawTitle();
        
        //Legend box 
        for (var i = 0; i < bubbles.length; i++) {
            this.LegendLabels(bubbles[i].name, i, bubbles[i].color);
        }
        
        strokeWeight(1);
    }
    
    this.drawTitle = function(){
        fill(255,250,0);
        noStroke();
        rect(-330, -300, 860, 40);
        
        fill(0);
        noStroke();
        textSize(20);
        textAlign('center', 'center');
        text(this.title, 100, -280);
    };
    
    this.LegendLabels = function(label, i, color) {
        var LabelWidth = 10;
        var LabelHeight = 20;
        var xPos = -width + 700
        var yPos = -220 + (LabelHeight + 2) * i;
        
        fill(color);
        rect(xPos, yPos, LabelWidth, LabelHeight);

        fill(0);
        strokeWeight(4);
        textAlign('left', 'center');
        textSize(14);
        text(label, xPos + LabelWidth + 10, yPos + LabelHeight / 2);
    }

//END of own code PART 2
    
    this.data_setup = function(){
        bubbles = [];
        maxAmt = 0;
        years = [];
        
        var rows = this.data.getRows();
        var ColumnsNum = this.data.getColumnCount();
        
//START of own code PART 3
        
        // dropdown menu for years
        var dropdown = createSelect();
        dropdown.parent('years');
        dropdown.position(320, 50);
        dropdown.option('SELECT YEAR');
        dropdown.changed(function() {
            dropMenuYearChange(dropdown.value(), years, bubbles);
        });
        
        //Starts from column index 5 because in csv file, year starts from 5
        //creates dropdown option for each year
        for(var i = 5; i < ColumnsNum; i++){
            var y = this.data.columns[i];
            years.push(y);
            dropdown.option(y);
        }

//END of own code PART 3
        
        //create bubbles for each food type (data from 1974 to 2016)
        for(var i = 0; i < rows.length; i++){
            if(rows[i].get(0) != ""){
                //Set food name
                var bubs = new Bubble(rows[i].get(0));
                
                for(var j = 5; j < ColumnsNum; j++){
                    if(rows[i].get(j) != ""){
                        var n = rows[i].getNum(j);
                        if(n > maxAmt){
                            maxAmt = n; //Record of the highest value
                        }
                        bubs.data.push(n);
                    } else {
                        bubs.data.push(0); //empty value
                    }
                }
                bubbles.push(bubs);
            }
        }
        
        for(var i = 0; i < bubbles.length; i++){
            bubbles[i].setMaxAmt(maxAmt);
            bubbles[i].setData(0); //Set to first data 
        }
    }
    
    function dropMenuYearChange(year, years, _bubbles){
        var y = years.indexOf(year);
        
        for(var i = 0; i < bubbles.length; i++){
            bubbles[i].setData(y);
        }
    }
}