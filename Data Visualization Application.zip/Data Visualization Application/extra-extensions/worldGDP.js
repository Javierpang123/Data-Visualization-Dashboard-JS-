function worldGDP(){
    this.name = "GDP by Country 1999-2021";
    
    this.id = "country-gdp";
    
    this.loaded = false;
    
    this.xAxisLabel = 'years';
    this.yAxisLabel = '$ in Billions';
    
    var marginSize = 50;
  
    this.preload = function() {
        var self = this;
        this.data = loadTable('./data/worldGDP/GDP-by-Country1999-2022.csv', 'csv', 'header',
        // Callback function
        function(table) {
            self.loaded = true;
        });
    };
    
    //Object for plot measurements and methods
    this.layout = {
        marginSize: marginSize,
        
        //Margin positions 
        leftMargin: marginSize * 2,
        rightMargin: 1150 - marginSize,
        topMargin: marginSize + 50,
        bottomMargin: height - marginSize * 1.2,
        pad: 8,
        
        plotWidth: function(){
            return this.rightMargin - this.leftMargin;
        },
            
        plotHeight: function(){
            return this.bottomMargin - this.topMargin;
        },
            
        grid: true,
        
        numXTickLabels: 10,
        numYTickLabels: 8
    };
    
//START of own code PART 1
     this.setup = function() {
        textSize(16);
        this.startYear = Number(this.data.columns[1]);
        this.endYear = Number(this.data.columns[this.data.columns.length -1]);
        this.numYears = this.endYear - this.startYear + 1;
         
        //Tab 1 (Individual Country Tab) & TAB Functionality's HTML element setup
        this.Tab1Setup();
         
        //Tab 2 (Comparison Chart Tab) HTML element setup
        this.Tab2Setup();
         
        //Individual Country GDP Tab's Default selected country settings
        this.selectedCountry = 'Singapore';
        this.selectedCountryHighestGDP = this.getMaxGDP(this.selectedCountry);
        this.countryMenu.value(this.selectedCountry); //Set default value in the dropdown menu
        
        //Comparison Chart Tab's Default selected settings
        this.countryMenu1.value('Singapore');
        this.countryMenu2.value('United Kingdom'); 
        
        //Default selected tab
        this.openTab('individualCountryGDP');

    }
    
    //TAB Functionality & Individual country tab HTML element setup
    this.Tab1Setup = function(){
        
        //Create tab buttons (individual & comparison tabs)
        this.tab1 = createDiv('');
        this.tab1.id('individualCountryGDP');
        this.individualButton = createButton('Individual Country GDP');
        this.individualButton.position(650, 20);
        this.individualButton.style('width', '250px');
        this.individualButton.style('padding','20px 20px');
        this.individualButton.style('font-weight', 'bold');
        this.individualButton.style('background-color', 'grey');
        this.individualButton.mousePressed(() => this.openTab('individualCountryGDP'));

        this.tab2 = createDiv('');
        this.tab2.id('comparisonChart');
        this.comparisonButton = createButton('Comparison Chart');
        this.comparisonButton.position(890, 20);
        this.comparisonButton.style('width', '200px');
        this.comparisonButton.style('padding','20px 20px');
        this.comparisonButton.style('font-weight', 'bold');
        this.comparisonButton.style('background-color', 'grey');
        this.comparisonButton.mousePressed(() => this.openTab('comparisonChart'));
        
        //Dropdown menu for individual country tab selection
        this.countryMenu = createSelect();
        this.countryMenu.position(1215, 88);
    
        //Populates Dropdown menu options with country name from csv file
        for (var i = 0; i < this.data.getRowCount(); i++) {
            this.countryMenu.option(this.data.getString(i, 0));
        }
        
        //Updates variables below based on the dropdown menu value in individual country tab.
        this.updateCountryOption = function() {
            this.selectedCountry = this.countryMenu.value();
            this.selectedCountryHighestGDP = this.getMaxGDP(this.selectedCountry);
        };
        
        this.countryMenu.changed(this.updateCountryOption.bind(this));
    }
    
    //Comparison chart tab HTML element setup
    this.Tab2Setup = function(){
        //Button to toggle comparison options menu
        this.comparisonOptions = createButton('Click for Comparison Options');
        this.comparisonOptions.position(1200, 20);
        this.comparisonOptions.style('width', '250px');
        this.comparisonOptions.style('padding', '20px 20px');
        this.comparisonOptions.style('font-weight', 'bold');
        this.comparisonOptions.style('background-color', 'yellow');


        // User's comparison input div for comparison section
        this.comparisonOptionDiv = createDiv('');
        this.comparisonOptionDiv.id('comparisonSectionTab');
        this.comparisonOptionDiv.style('display', 'none');
        this.comparisonOptionDiv.position(650, 200);
        this.comparisonOptionDiv.style('width', '400px');
        this.comparisonOptionDiv.style('height', '50px');
        this.comparisonOptionDiv.style('background-color', 'blue'); 
        this.comparisonOptionDiv.style('border', '2px solid #ccc');   // Light gray border
        this.comparisonOptionDiv.style('padding', '20px');
        this.comparisonOptionDiv.style('border-radius', '10px'); // Rounded corners

        // Function to open and close the comparison div via mousePressed
        var toggleComparisonOptions = () => {
            if (this.comparisonOptionDiv.style('display') == 'none') {
                this.comparisonOptionDiv.style('display', 'block');
            } else {
                this.comparisonOptionDiv.style('display', 'none');
            }
        };

        this.comparisonOptions.mousePressed(toggleComparisonOptions);

        //Country Menu 1 to select first country for comparison
        this.countryMenu1 = createSelect();
        this.countryMenu1.parent(this.comparisonOptionDiv); //Parent div element
        this.countryMenu1.position(10, 10);
        
        this.country1 = function() {
            this.country1Selected = this.countryMenu1.value();
        };
        
        this.countryMenu1.changed(this.country1.bind(this));
        
        //Country Menu 2 to select second country for comparison
        this.countryMenu2 = createSelect();
        this.countryMenu2.parent(this.comparisonOptionDiv); //Parent div element
        this.countryMenu2.position(220, 10);
        
        this.country2 = function() {
            this.country2Selected = this.countryMenu2.value();
        };
        
        this.countryMenu2.changed(this.country2.bind(this));
        
        //Populate countryMenu 1 & 2 options
        for (var i = 0; i < this.data.getRowCount(); i++) {
            this.countryMenu1.option(this.data.getString(i, 0));
            this.countryMenu2.option(this.data.getString(i, 0));
        }
        
        //Dropdown menu for start year & end year for year range
        this.startYearMenu = createSelect();
        this.startYearMenu.parent(this.comparisonOptionDiv); //Parent div element
        this.startYearMenu.position(10, 30);
        this.startYearMenu.style('width', '208px');
        this.startYearMenu.option('Select Start Year (From: )');
        
        this.endYearMenu = createSelect();
        this.endYearMenu.parent(this.comparisonOptionDiv); //Parent div element
        this.endYearMenu.position(220, 30);
        this.endYearMenu.style('width', '208px');
        this.endYearMenu.option('Select End Year (To: )');
        
        //Populate dropdown list options for years option  (1999 to 2021);
        for (var i = 1; i < this.data.getColumnCount(); i++) {
            this.startYearMenu.option(Number(this.data.columns[i]));
            this.endYearMenu.option(Number(this.data.columns[i]));
        }

        // Button to trigger comparison function
        this.triggerButton = createButton('Compare');
        this.triggerButton.parent(this.comparisonOptionDiv); //Parent div element
        this.triggerButton.position(10, 50);
        this.triggerButton.style('width', '418px');
        this.triggerButton.style('padding', '5px 5px');
        this.triggerButton.style('font-weight', 'bold');
        this.triggerButton.style('background-color', 'yellow');
        this.triggerButton.mousePressed(this.comparisonTool.bind(this));
    }

    //DESTROY ALL HTML ELEMENT
    this.destroy = function() {
        this.individualButton.remove();
        this.comparisonButton.remove();
        this.countryMenu.remove();
        this.comparisonOptions.remove();
        this.comparisonOptionDiv.remove();
        this.countryMenu1.remove();
        this.countryMenu2.remove();
        this.startYearMenu.remove();
        this.endYearMenu.remove();
        this.triggerButton.remove(); 
    }
    
    this.draw = function() {
        noStroke();
        if (!this.loaded) {
            console.log('Data has not been loaded yet!');
            return;
        }
        
        //INDVIDUAL COUNTRY GDP TAB DRAWING
        if (this.activeTab == 'individualCountryGDP') {
            //MIN and MAX values for the Y-axis
            this.minGDP = 0;
            this.maxGDP = this.selectedCountryHighestGDP
            
            //Axis and axis labels
            this.drawTitle();
            drawAxis(this.layout);
            drawAxisLabels(this.xAxisLabel, this.yAxisLabel, this.layout);
            textSize(14);
            
            //Y-axis labels
            customYAxisTickLabel(this.minGDP, this.maxGDP, this.layout, this.mapDollarsToHeight.bind(this), 2);
            
            //X-axis labels
            var year = this.startYear;
            for(var i = 0; i < this.numYears; i++){
                textSize(14);
                customXAxisTickLabel(year, this.layout,
                                   this.mapYearToWidth.bind(this));
                year++;
                textSize(16);
            }
            
            //Column Chart Drawing for individual Country
            var dataRow = this.data.findRow(this.selectedCountry, 0);
            if (dataRow !== null) {
                var mouseXOver = -1; //Initialize mouseXOver only
                var mouseYOver = -1; //Initialize mouseXOver only
                var dollarInfo = ""; //Used to store column info later

                for (var i = 1; i < this.data.getColumnCount(); i++) {
                    var x = this.mapYearToWidth(Number(this.data.columns[i]));
                    var y = this.mapDollarsToHeight(parseFloat(dataRow.getString(i)));
                    var barWidth = (this.layout.plotWidth() / this.numYears) * 0.6; 

                    //Mouse Hover Checking Variable
                    var isMouseOver = mouseX > x + 12 - barWidth / 2 
                    && mouseX < x + 12 + barWidth 
                    && mouseY < this.layout.bottomMargin && mouseY > y;

                    //If mouse is hovering inside column, expand column and declare column info text
                    if (isMouseOver) {
                        fill(255,0,0);
                        mouseXOver = x;
                        mouseYOver = y;
                        barWidth *= 1.2; //Make column chart bigger to make interactive hover effect
                        dollarInfo = `Year: ${this.data.columns[i]}\nGDP: $${dataRow.getString(i)} Billion`; //Set Column Chart Information Text
                    } else {
                        fill(0,0,205);
                    }
                    
                    //Column chart rectangle drawing
                    rect(x + 12, y, barWidth, this.layout.bottomMargin - y);
                }

                //Show Column information after drawing all bars so that text will appear infront 
                if (dollarInfo !== "") {
                    fill(255,255,0);
                    stroke(0);
                    strokeWeight(2);
                    rect(mouseX + 15, mouseY - 35, 170, 50);
                
                    fill(0);
                    noStroke();
                    textSize(16);
                    text(dollarInfo, mouseX + 100, mouseY - 10);
                }
            }
        
        //COMPARISON CHART TAB DRAWING
        } 
        else if (this.activeTab == 'comparisonChart') {

            if (!this.country1GDPData || !this.country2GDPData || this.country1GDPData.length == 0 || this.country2GDPData.length == 0 || this.start > this.end) {
                return;
            }

            // Title, Axis and axis labels drawings
            this.drawTitle();
            drawAxis(this.layout);
            drawAxisLabels(this.xAxisLabel, this.yAxisLabel, this.layout);

            // Y-axis labels
            customYAxisTickLabel(0, this.topGDP, this.layout, this.mapComparisonDollarsToHeight.bind(this), 2);

            // X-axis labels
            var year = this.start;
            for (var i = 0; i < this.yearCount; i++) {
                customXAxisTickLabel(year, this.layout, this.mapComparisonYearToWidth.bind(this));
                year++;
            }

            // Comparison Column Chart Drawings
            var barWidth = (this.layout.plotWidth() / Math.max(2, this.yearCount)) * 0.2;

            var year = this.start;
            var mouseXOver = -1;
            var mouseYOver = -1;
            var dollarInfo = "";

            for (var i = 0; i < this.yearCount; i++) {

                // Country 1 Column Chart Drawing (Left column)
                if (i < this.country1GDPData.length) {
                    var xPOS1 = this.mapComparisonYearToWidth(year);
                    var yPOS1 = this.mapComparisonDollarsToHeight(this.country1GDPData[i]);

                    // Mouse hover functionality check
                    var isMouseOver1 = mouseX > xPOS1 + 10 - barWidth / 2 
                    && mouseX < xPOS1 + 10 + barWidth 
                    && mouseY < this.layout.bottomMargin && mouseY > yPOS1;

                    if (isMouseOver1) {
                        fill(255,0,0);
                        mouseXOver = xPOS1;
                        mouseYOver = yPOS1;
                        dollarInfo = `Year: ${year}\n${this.countryMenu1.value()} GDP: $${this.country1GDPData[i]} Billion`;
                    } else {
                        fill('blue');
                    }

                    rect(xPOS1 + 10, yPOS1, barWidth, this.layout.bottomMargin - yPOS1);
                    noStroke();
                }

                // Country 2 Column Chart Drawing (Right column)
                if (i < this.country2GDPData.length) {
                    var xPOS2 = this.mapComparisonYearToWidth(year);
                    var yPOS2 = this.mapComparisonDollarsToHeight(this.country2GDPData[i]);

                    // Mouse hover functionality check
                    var isMouseOver2 = mouseX > xPOS2 + 30 - barWidth / 2 
                    && mouseX < xPOS2 + 30 + barWidth 
                    && mouseY < this.layout.bottomMargin && mouseY > yPOS2;

                    if (isMouseOver2) {
                        fill(255,140,0);
                        mouseXOver = xPOS2;
                        mouseYOver = yPOS2;
                        dollarInfo = `Year: ${year}\n${this.countryMenu2.value()} GDP: $${this.country2GDPData[i]} Billion`;
                    } else {
                        fill('purple');
                    }
                    rect(xPOS2 + 30, yPOS2, barWidth, this.layout.bottomMargin - yPOS2);
                    noStroke();
                }
                year++;
            }

            // Show Column information after drawing all bars so that text will appear in front 
            if (dollarInfo !== "") {

                // Calculate the width and height of the info text
                textSize(16);
                var Width = max(textWidth(dollarInfo.split('\n')[0]), textWidth(dollarInfo.split('\n')[1]));
                var Height = 50;

                //Background
                fill(255,255,0);
                stroke(0);
                strokeWeight(2);
                rect(mouseX + 15, mouseY - 35, Width + 20, Height);

                //Text
                fill(0);
                noStroke();
                textAlign(LEFT, CENTER);
                text(dollarInfo, mouseX + 25, mouseY - 10);
                textAlign(CENTER, CENTER);
            }

            this.drawLegend();
        }
        
        noStroke();
    };
    
    //Individual Country GDP / Comparison Chart TITLE function
    this.drawTitle = function(){
        fill(0);
        noStroke();
        textSize(16);
        textAlign('center', 'center');
        
        if (this.activeTab == 'individualCountryGDP'){
            var title = this.countryMenu.value() + "'s GDP Data Visualization (1999-2021)";
            
        }else if (this.activeTab == 'comparisonChart'){
            var title = `GDP Comparison: ${this.countryMenu1.value()} vs ${this.countryMenu2.value()} (${this.start}-${this.end})`;
        }
        
        //Display text
        text(title, (this.layout.plotWidth() / 2) + this.layout.leftMargin, 90);
    };
    
    
    //Comparison chart's legend drawing 
    this.drawLegend = function() {
        fill(0);
        textAlign(LEFT, CENTER);
        textSize(14);

        //country 1 legend
        fill('blue');
        rect(this.layout.leftMargin + 30, this.layout.topMargin - 70, 20, 20);
        fill(0);
        text(this.countryMenu1.value(), this.layout.leftMargin + 60, this.layout.topMargin - 60);

        //country 2 legend
        fill('purple');
        rect(this.layout.leftMargin + 30, this.layout.topMargin - 40, 20, 20);
        fill(0);
        text(this.countryMenu2.value(), this.layout.leftMargin + 60, this.layout.topMargin - 30);
    };
    
    //Width and Height scaling for Individual Country GDP chart
    this.mapYearToWidth = function(value) {
        return map(value, this.startYear, this.endYear, this.layout.leftMargin, this.layout.rightMargin);
    };
    
    
    this.mapDollarsToHeight = function(value) {
        return map(value, this.minGDP, this.maxGDP, this.layout.bottomMargin, this.layout.topMargin);
    };
    
    //Width and Height scaling for Comparison Chart 
    this.mapComparisonYearToWidth = function(value) {
        
        //Handles single year comparison and sets year to be in the center of graph.
        if (this.start == this.end) {
            return (this.layout.leftMargin + this.layout.rightMargin) / 2;
        }
        
        return map(value, this.start, this.end, this.layout.leftMargin, this.layout.rightMargin);
    };

    this.mapComparisonDollarsToHeight = function(value) {
        return map(value, 0, this.topGDP, this.layout.bottomMargin, this.layout.topMargin);
    };
    
    //Algorithm to get HIGHEST GDP of selected country via Dropdown menu
    this.getMaxGDP = function(country) {
        var highestGDP = 0;
        
        for (var i = 0; i < this.data.getRowCount(); i++) {
            if (this.data.getString(i, 0) == country) {
                for (var j = 1; j < this.data.getColumnCount(); j++) {
        
                    var gdp = parseFloat(this.data.getString(i, j));
                    if (gdp > highestGDP) {
                        highestGDP = gdp;
                    }
                }
                //Put break so that it wouldn't check other row after match found to be efficient
                break; 
            }
        }
        return highestGDP;
    };
  
    //SWITCH TAB FUNCTIONALITY CODE 
    this.openTab = function(tabName) {
        
        document.getElementById('individualCountryGDP').style.display = 'none';
        document.getElementById('comparisonChart').style.display = 'none';

        //Show the selected tab
        document.getElementById(tabName).style.display = 'block';

        //Edit tab color. E.g if comparison tab chosen, orange background indicates active tab
        if (tabName === 'individualCountryGDP') {
            this.individualButton.style('background-color', 'orange');
            this.comparisonButton.style('background-color', 'grey');
            
            this.countryMenu.show();
            
            this.comparisonOptions.hide();
            this.comparisonOptionDiv.style('display', 'none');
            this.comparisonOptionDiv.hide();
            this.activeTab = 'individualCountryGDP';
            
        } else if (tabName === 'comparisonChart') {
            this.individualButton.style('background-color', 'grey');
            this.comparisonButton.style('background-color', 'orange');
            
            this.countryMenu.hide();
            this.comparisonOptions.show();
            this.comparisonOptionDiv.style('display', 'block');
            
            this.activeTab = 'comparisonChart';
        }
        
        this.activeTab = tabName;
    };
    
    //Comparison Tool Function extracts out information from csv Data file based on information retrieve via comparison option user selection.
    this.comparisonTool = function() {
        
        //Hides all comparison input HTML elements after the comparisonTool function is triggered using the compare button.
        this.comparisonOptionDiv.style('display', 'none');
        
        //Store dropdown value for selected countries
        var country1 = this.countryMenu1.value();
        var country2 = this.countryMenu2.value();
        
        this.topGDP = 0;

        //Get the selected years
        this.start = Number(this.startYearMenu.value());
        this.end = Number(this.endYearMenu.value());
        
        //Error handling to ensure that user doesnt enter a end year smaller than start year
        if (this.end < this.start) {
            alert("Error: End year cannot be smaller than start year.");
            return;
        }

        this.yearCount = this.end - this.start + 1;
        
        this.country1GDPData = [];
        this.country2GDPData = [];
        
        var country1HighestGDP = 0;
        var country2HighestGDP = 0;

        var years = this.data.columns.slice(1).map(Number); // Extract years
        var startIndex = years.indexOf(Number(this.start));
        var endIndex = years.indexOf(Number(this.end));
        
        if (startIndex == -1 || endIndex == -1 || startIndex > endIndex) {
            alert("Error: Invalid year range.");
            return;
        }

        //Extract GDP data for both countries within the year range given
        for (let i = 0; i < this.data.getRowCount(); i++) {
            var country = this.data.getString(i, 0);
            if (country == country1 || country == country2) {
                this.rowData = this.data.getRow(i).arr.slice(1).map(Number);
                
                //Extract GDP data for the year range 
                this.gdpData = this.rowData.slice(startIndex, endIndex + 1); 

                if (country == country1) {
                    this.country1GDPData = this.gdpData;
                    country1HighestGDP = Math.max(...this.gdpData);
            
                } else if (country == country2) {
                    this.country2GDPData = this.gdpData;
                    country2HighestGDP = Math.max(...this.gdpData);
                }
            }
        }
        
        //Compares the Highest GDP of both country and sets the highest to this.topGDP to be used as the maximun y-axis value for column chart 
        if(country1HighestGDP > country2HighestGDP){
            this.topGDP = country1HighestGDP;
        } else {
            this.topGDP = country2HighestGDP;
        }
    }
}
//END of own code PART 1 