function NutrientsTimeSeries() {

    this.name = "Nutrients: 1974-2016";
    
    this.id = "nutrients-timeseries";
    
    this.loaded = false;

    this.title = "Nutrients: 1974-2016";
    
    // Axis name
    this.xAxisLabel = 'year';
    this.yAxisLabel = 'Percentage (%)';
    
    this.colors = [];
    
    var marginSize = 50;
    
    //Object for plot measurements and methods
    this.layout = {
        marginSize: marginSize,
        
        //Margin positions 
        leftMargin: marginSize * 2,
        rightMargin: 1150 - marginSize,
        topMargin: marginSize,
        bottomMargin: height - marginSize * 2,
        pad: 15,
        
        plotWidth: function(){
            return this.rightMargin - this.leftMargin;
        },
            
        plotHeight: function(){
            return this.bottomMargin - this.topMargin;
        },
            
        grid: true,
        
        numXTickLabels: 10,
        numYTickLabels: 8,
    };
    
    this.preload = function() {
        var self = this;
        this.data = loadTable('./data/food/nutrients74-16.csv', 'csv', 'header',
        function(table) {
            self.loaded = true;
        });
    };
    
    this.setup = function(){
        textSize(16);
        // Set minimum and maximum years
        this.startYear = Number(this.data.columns[1]);
        this.endYear = Number(this.data.columns[this.data.columns.length -1]);
        
        for(var i = 0; i < this.data.getRowCount(); i++){
            this.colors.push(color(random(0,160),random(0,160),random(0,160)));
        }
        
        //Set min and max percentage
        this.minPercentage = 80;
        this.maxPercentage = 400;
        
//START of own code PART 1
        
        // Create input fields for year comparison
        this.year1 = createInput('');
        this.year1.position(660, height);
        this.year1.attribute('placeholder', 'Enter first year');
        this.year1.style('width', '199px');
        
        this.year2 = createInput('');
        this.year2.position(840, height);
        this.year2.attribute('placeholder', 'Enter second year');
        this.year2.style('width', '199px');
        
        this.button = createButton('Compare');
        this.button.position(1020, height);
        this.button.style('width', '99px')
        
        //Links the comparisonTool function to be executing when the compare button is pressed.
        this.button.mousePressed(this.comparisonTool.bind(this));
        
        //div for displaying the comparison results
        this.comparisonDiv = createDiv('');
        this.comparisonDiv.position(660, height + 20);
        
        //dropdown menu for nutrient selection
        this.DropDownMenu = createSelect();
        this.DropDownMenu.position(1180, 25);
        this.DropDownMenu.option('All Nutrients'); // Option to display all nutrients
    
        //Add dropdown list options with nutrient name from csv file
        for (var i = 0; i < this.data.getRowCount(); i++) {
            this.DropDownMenu.option(this.data.getString(i, 0));
        }
        
        this.DropDownMenu.changed(this.updateNutrientOption.bind(this));
        
    };
    
    this.destroy = function(){
        this.DropDownMenu.remove();
        this.year1.remove();
        this.year2.remove();
        this.button.remove();
        this.comparisonDiv.remove();
    };

//END of own code PART 1
    
    this.draw = function(){
        console.log(this.colours);
        if(!this.loaded){
            console.log('Data has not been loaded yet!');
            return;
        }

        //Plot title
        this.drawTitle();

        //Y axis labels
        drawYAxisTickLabels(this.minPercentage,
                            this.maxPercentage,
                            this.layout,
                            this.mapNutrientsToHeight.bind(this), 
                            0);

        drawAxis(this.layout);

        drawAxisLabels(this.xAxisLabel, this.yAxisLabel, this.layout);
             
//START of own code PART 2
        
        var numYears = this.endYear - this.startYear + 1; // Include the end year
        
        //Set to -1 to ensure no specific nutrient is selected
        var selectedIndex = -1; 
        //Finds the selected nutrient index based on the data file
        if (this.selectedNutrient !== 'All Nutrients') {
            for (var i = 0; i < this.data.getRowCount(); i++) {
                var nutrient = this.data.getString(i, 0);
                if (nutrient == this.selectedNutrient) {
                    selectedIndex = i;
                    break;
                }
            }
        }

        //draw lines from previous value to current value
        for(var i = 0; i < this.data.getRowCount(); i++){
            var row = this.data.getRow(i);
            var previous = null;

            var title = row.getString(0);
            
            //It will only draw the selected nutrient
            if (i !== selectedIndex && selectedIndex !== -1) {
                continue;
            }
    
//END of own code PART 2

            for (var j = 1; j <= numYears; j++){ // Loop from 1 to numYears

                //Current year's data object
                var current = {
                    'year': this.startYear + j - 1,
                    'percentage': row.getNum(j)
                };

                if(previous != null){

                    //Line to connect previous and current year
                    stroke(this.colors[i]);
                    line(this.mapYearToWidth(previous.year),
                        this.mapNutrientsToHeight(previous.percentage),
                        this.mapYearToWidth(current.year),
                        this.mapNutrientsToHeight(current.percentage));
                        
                    var currentSize = textSize();
                    textSize(10);
                    drawXAxisTickLabel(previous.year, this.layout,
                                       this.mapYearToWidth.bind(this));
                    textSize(currentSize);
                } else {
                    noStroke();
                    this.LegendLabels(title, i, this.colors[i]);
                }

                previous = current;
            }

            // Add the last year separately to include 2016
            if (previous != null) {
                var current = {
                    'year': this.endYear,
                    'percentage': row.getNum(numYears)
                };

                stroke(this.colors[i]);
                strokeWeight(1);
                line(this.mapYearToWidth(previous.year),
                    this.mapNutrientsToHeight(previous.percentage),
                    this.mapYearToWidth(current.year),
                    this.mapNutrientsToHeight(current.percentage));

                // Draw the last x axis tick label if needed
                var currentTextSize = textSize();
                textSize(10);
                drawXAxisTickLabel(current.year, this.layout,
                                   this.mapYearToWidth.bind(this));
                textSize(currentTextSize); 
            }
        }
        
//START of own code PART 3 
        this.NutrientGraphInfo(); //Display nutrient % and year on graph

        //Comparison Tool extension text
        noStroke();
        textSize(21);
        textAlign('left', 'center');
        fill(0);
        rect(388, height - 35, 460, 26);
        fill(255,255,0);
        text("COMPARISON TOOL", 508, height - 20);
    };
    
    //Comparison tool functionality function
    this.comparisonTool = function(){
        
        //Converts the valid from user year input to integer 
        var yearvalue1 = int(this.year1.value());
        var yearvalue2 = int(this.year2.value());
        
        //Checks if value enter is less than start year 1974 or more than end year 2015
        if(yearvalue1 < this.startYear || yearvalue1 > this.endYear || yearvalue2 < this.startYear || yearvalue2 > this.endYear){
            console.log('Invalid years entered.');
            this.comparisonDiv.html('Invalid years entered.');
            return;
        }
        
        //Converts year input to index, eg. input=1974, index1 = 1974 - this.startYear(1974)+1 = 1 
        var index1 = yearvalue1 - this.startYear + 1;
        var index2 = yearvalue2 - this.startYear + 1;
        
        // Create a comparison table
        var comparisonTable = '<table border="3" cellpadding="5" cellspacing="0"><tr><th>Nutrient</th><th>' + yearvalue1  + '</th><th>' + yearvalue2 + '</th><th>Difference</th></tr>';
        
        for(var i = 0; i < this.data.getRowCount(); i++){
            var row = this.data.getRow(i);
            var nutrient = row.getString(0);
            var percentage1 = row.getNum(index1); //Get percentage of year 1's nutrient
            var percentage2 = row.getNum(index2); //Get percentage of year 2's nutrient
            var difference = percentage2 - percentage1; //Calculates Percentage Difference
            
            //HTML table formatting
            comparisonTable += '<tr><td>' + nutrient + '</td><td>' + percentage1.toFixed(2) + "%" + '</td><td>' + percentage2.toFixed(2) + "%" + '</td><td>' + difference.toFixed(2) + "%" + '</td></tr>';
        }
        
        //Close the table tag
        comparisonTable += '</table>';
        
        this.comparisonDiv.html(comparisonTable);
    };
    
    //Legendbox object is used to draw legend color for different nutrients
    this.LegendLabels = function(title, i, color){
        var width = 10;
        var height = 50;
        var xPos = 1125;
        var yPos = 50 + (height+2) * i;
        
        noStroke();
        fill(color);
        rect(xPos, yPos, width, height);
        
        fill(0);
        noStroke();
        textAlign('left', 'center');
        textSize(11);
        text(title, xPos + width + 10, yPos + height/2);
    }
    
    this.updateNutrientOption = function() {
        this.selectedNutrient = this.DropDownMenu.value();
    };
    
//END of own code PART 3
    
    this.drawTitle = function(){
        fill(0);
        noStroke();
        textSize(16);
        textAlign('center', 'center');
        text(this.title,
            (this.layout.plotWidth() / 2) + this.layout.leftMargin, this.layout.topMargin - (this.layout.marginSize / 2));
    };
    
    this.mapYearToWidth = function(value) {
        return map(value, this.startYear, this.endYear, this.layout.leftMargin, this.layout.rightMargin);
    };
    
    this.mapNutrientsToHeight = function(value) {
        return map(value, this.minPercentage, this.maxPercentage, this.layout.bottomMargin, this.layout.topMargin)
    };
    

//Start of own code PART 4 
    //Generates graph information box when mouse hovers over a line
    //Uses checkIfMouseNearLine*() function to for mouse hover functionality
    this.NutrientGraphInfo = function() {
        var TotalYears = this.endYear - this.startYear + 1;
        for (var i = 0; i < this.data.getRowCount(); i++) {
            var row = this.data.getRow(i);
            var previous = null;
            var title = row.getString(0);

            for (var j = 1; j <= TotalYears; j++) {
                var current = {
                    'year': this.startYear + j - 1,
                    'percentage': row.getNum(j)
                };

                if (previous != null) {
                    var xPos1 = this.mapYearToWidth(previous.year);
                    var yPos1 = this.mapNutrientsToHeight(previous.percentage);
                    var xPos2 = this.mapYearToWidth(current.year);
                    var yPos2 = this.mapNutrientsToHeight(current.percentage);

                    if (this.checkIfMouseNearLine(mouseX, mouseY, xPos1, yPos1, xPos2, yPos2)) {
                        fill(255,255,0);
                        stroke(0);
                        rect(mouseX + 10, mouseY - 5, 210, 50);
                        noStroke();
                        fill(0);
                        textSize(12);
                        textAlign('left', 'top');
                        text(`Nutrient: ${title}`, mouseX + 15, mouseY);
                        text(`Year: ${previous.year}`, mouseX + 15, mouseY + 15);
                        text(`Percentage: ${previous.percentage.toFixed(2)}%`, mouseX + 15, mouseY + 30);
                        return;
                    }
                }
                previous = current;
            }
        }
    };

    //Checks if the mouse is near a line segment
    this.checkIfMouseNearLine = function(mouseX, mouseY, x1, y1, x2, y2) {
        var distance1 = dist(mouseX, mouseY, x1, y1);
        var distance2 = dist(mouseX, mouseY, x2, y2);
        var length = dist(x1, y1, x2, y2);
        var buffer = 1; //Set to low buffer limit to more accurately differentiate lines that are close together

        return (distance1 + distance2 >= length - buffer && distance1 + distance2 <= length + buffer);
    };
}

//END of own code PART 4 