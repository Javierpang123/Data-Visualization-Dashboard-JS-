function Bubble(_name)
{
    //START (Editing the values)
    this.size = 10;
    this.target_size = this.size;
    this.pos = createVector(120,0);
    this.direction = createVector(0,0);
    this.name = _name;
    this.maxAmt = 0;
    this.color = color(random(0,255), random(0,255), random(0,255));
    this.data = [];
    //END
    
    this.draw = function() {
        push();
        noStroke();
        fill(this.color);
        ellipse(this.pos.x, this.pos.y, this.size);
        pop();
    }

    this.update = function(_bubbles) {
        this.direction.set(0, 0);

        for (var i = 0; i < _bubbles.length; i++) {
            if (_bubbles[i].name != this.name) {
                var v = p5.Vector.sub(this.pos, _bubbles[i].pos);
                var d = v.mag();

                if (d < this.size / 2 + _bubbles[i].size / 2) {
                    if (d > 0) {
                        this.direction.add(v)
                    } else {
                        this.direction.add(p5.Vector.random2D());
                    }
                }
            }
        }

        this.direction.normalize();
        this.direction.mult(2);
        this.pos.add(this.direction);

        if (this.size < this.target_size) {
            this.size += 1;
        } else if (this.size > this.target_size) {
            this.size -= 1;
        }
    }

    this.setData = function(i) {
        this.target_size = map(this.data[i], 0, this.maxAmt, 20, 250);
    }

    this.setMaxAmt = function(_maxAmt) {
        this.maxAmt = _maxAmt;
    }

//START 
    this.isMouseOverBubble = function() {
        var d = dist(mouseX - width / 2, mouseY - height / 2, this.pos.x, this.pos.y);
        return d < this.size / 2;
    }
//END
}
