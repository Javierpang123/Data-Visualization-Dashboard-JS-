function PieChart(x, y, diameter) {
    
    this.x = x;
    this.y = y; 
    this.diameter = diameter; 
    this.labelSpace = 30;
    this.hoverDiameter = this.diameter * 1.1; //Increased diameter for hover effect

    this.get_radians = function(data) {
        var total = sum(data); 
        var radians = []; 
        for (let i = 0; i < data.length; i++) {
            radians.push((data[i] / total) * TWO_PI); 
        }
        return radians;
    };

    this.draw = function(data, labels, colours, title) {
        
        if (data.length == 0) {
            alert('Data has length zero!');
        } else if (![labels, colours].every((array) => {
            return array.length == data.length;
        })) {
            alert(`Data (length: ${data.length})
            Labels (length: ${labels.length})
            Colours (length: ${colours.length})
            Arrays must be the same length!`);
        }

        var angles = this.get_radians(data);
        var lastAngle = 0; 
        var colour; 

        for (var i = 0; i < data.length; i++) {
            if (colours) {
                colour = colours[i];
            } else {
                colour = map(i, 0, data.length, 0, 255);
            }

            //Calculate the angle between the mouse position and the center of the pie chart.
            var mouseAngle = atan2(mouseY - this.y, mouseX - this.x);

            //mouseAngle provides a value between -PI and PI, so we adjust it to be between 0 and TWO_PI (0 - 360 degrees)
            if (mouseAngle < 0) {
                mouseAngle += TWO_PI;
            }

            //Calculate the distance from the mouse position to the center of the pie chart.
            var centerDistance = dist(mouseX, mouseY, this.x, this.y);

            //Checks if mouse is hovering over the current pie slice.
            var isMouseOver = mouseAngle > lastAngle && mouseAngle < lastAngle + angles[i] && centerDistance < this.diameter / 2;

            //Set arc diameter based on mouse hover 
            var arcDiameter = this.diameter;
            if (isMouseOver) {
                arcDiameter = this.hoverDiameter; //Enlarge the arc if mouse is over it
            }

            fill(colour); 
            stroke(0);
            strokeWeight(1);

            //Draw slices of pie chart
            arc(this.x, this.y, arcDiameter, arcDiameter, lastAngle, lastAngle + angles[i] + 0.001);

            if (isMouseOver) {
                var percentage = nf((data[i] / sum(data)) * 100, 1, 2); // Calculate the percentage of the current slice

                var information = percentage + '% of employees at ' + title.split(' ')[3] + ' are ' + labels[i];

                fill('black'); 
                noStroke(); 
                textAlign(CENTER, CENTER);
                textSize(18);

                text(information, 650, 570); 
            }

            if (labels) {
                this.makeLegendItem(labels[i], i, colour); 
            }

            lastAngle += angles[i];
        }

        if (title) {
            noStroke(); 
            textAlign('center', 'center'); 
            textSize(24);
            text(title, this.x, this.y - this.diameter * 0.6); 
        }
    };


    this.makeLegendItem = function(label, i, colour) {
    var x = this.x + 50 + this.diameter / 2; 
    var y = this.y + (this.labelSpace * i) - this.diameter / 3; 
    var boxWidth = this.labelSpace / 2;
    var boxHeight = this.labelSpace / 2; 

    fill(colour); 
    rect(x, y, boxWidth, boxHeight); 

    fill('black'); 
    noStroke(); 
    textAlign('left', 'center'); 
    textSize(12); 
    text(label, x + boxWidth + 10, y + boxWidth / 2); 
    };
}